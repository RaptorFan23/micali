-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 18-07-2023 a las 23:51:32
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tienda`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hombres`
--

CREATE TABLE `hombres` (
  `id` int(10) NOT NULL,
  `nombre_prenda` text NOT NULL,
  `talla` varchar(255) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `texto` varchar(255) NOT NULL,
  `existencia` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `hombres`
--

INSERT INTO `hombres` (`id`, `nombre_prenda`, `talla`, `precio`, `texto`, `existencia`) VALUES
(1, 'oaLO', 'xd', 13.00, 'dahjo', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `login_usuarios`
--

CREATE TABLE `login_usuarios` (
  `id` int(11) NOT NULL,
  `nombre_completo` varchar(50) NOT NULL,
  `telefono` varchar(50) NOT NULL,
  `correo` varchar(50) NOT NULL,
  `contrasena` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `login_usuarios`
--

INSERT INTO `login_usuarios` (`id`, `nombre_completo`, `telefono`, `correo`, `contrasena`) VALUES
(1, 'Marco', '5545355394', 'goku46265@gmail.com', 'goku500'),
(2, 'Jose Aceves Eusebio', '5562232614', 'joseaceves35296@gmail.com', '1234'),
(3, 'Mamaguevo', '5512048343', '22302040@utfv.edu.mx', 'oa');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mujeres`
--

CREATE TABLE `mujeres` (
  `id` int(10) NOT NULL,
  `nombre_prenda` varchar(255) NOT NULL,
  `talla` varchar(255) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `texto` varchar(255) NOT NULL,
  `existencia` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `mujeres`
--

INSERT INTO `mujeres` (`id`, `nombre_prenda`, `talla`, `precio`, `texto`, `existencia`) VALUES
(1, 'oa', 'mediogrande', 14.00, 'deh', 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ninas`
--

CREATE TABLE `ninas` (
  `id` int(10) NOT NULL,
  `nombre_prenda` varchar(255) NOT NULL,
  `talla` varchar(255) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `texto` varchar(255) NOT NULL,
  `existencia` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ninos`
--

CREATE TABLE `ninos` (
  `id` int(10) NOT NULL,
  `nombre_prenda` varchar(255) NOT NULL,
  `talla` varchar(255) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `texto` varchar(255) NOT NULL,
  `existencia` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ninos`
--

INSERT INTO `ninos` (`id`, `nombre_prenda`, `talla`, `precio`, `texto`, `existencia`) VALUES
(1, 'Sudadera', 'M', 250.00, 'cobija chido', 3),
(2, 'dkjvskjvs', 'fbudsfhsdf', 12.00, 'fhsdhfwkf', 3),
(23, 'perro', 'que', 13.00, 'cefjerfjnefkndvecec', 5);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `hombres`
--
ALTER TABLE `hombres`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `login_usuarios`
--
ALTER TABLE `login_usuarios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `mujeres`
--
ALTER TABLE `mujeres`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `ninas`
--
ALTER TABLE `ninas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `ninos`
--
ALTER TABLE `ninos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `hombres`
--
ALTER TABLE `hombres`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `login_usuarios`
--
ALTER TABLE `login_usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `mujeres`
--
ALTER TABLE `mujeres`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `ninas`
--
ALTER TABLE `ninas`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `ninos`
--
ALTER TABLE `ninos`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
