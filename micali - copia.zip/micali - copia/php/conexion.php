<?php

//archivo de che 
//conoexion a la base de datos

 $conexion = mysqli_connect("localhost", "root", "", "tienda");
 
 if($conexion){
    echo 'conectado';
 }else{
    echo 'no conectado';
 }
 

?>