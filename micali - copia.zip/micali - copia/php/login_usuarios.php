<?php

//ARCHIVO DE CHE 
//ENTRADA A USUARIOS YA REGISTRADOS Y AL ADMINISTRADOR

 session_start();

include 'conexion.php';

$correo =$_POST['correos'];
$contrasena =$_POST['contrasenas'];
if($correo == "goku46265@gmail.com"||$contrasena == "goku500"){
    $_SESSION['usuarrio'] = $correo;
    header("location:../php/PORTADA.php");

}else{

$validar_login = mysqli_query($conexion, "SELECT * FROM login_usuarios WHERE correo='$correo' and contrasena='$contrasena'");

if(mysqli_num_rows($validar_login) > 0){
    $_SESSION['usuarrio'] = $correo;
    header("location:../Carrito.php");
}else{
    echo'
    <script>
        alert("Usuario no existente, porfavor verifique los datos");
        window.location = "../php/index.php";
    </script>
    ';
    exit();
}


}

?>
