<!doctype html>
<html lang="en">
<head>
  <title>A-NIÑOS</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
  <link rel="stylesheet" href="../css/ofertas.css">
</head>

<body>
  <div class="encabezado">
    <div id="cuadro-blanco">NIÑOS</div>
    <a id="carrito" href="../index.html"><img src="../css/Imagenes/casita.png" width="40px" height="40px"></a>
  </div>
  <div class="encabezado">
    <a class="paginas" href="../php/PORTADA.php">INICIO</a>
    <a class="paginas" href="../php-mujeres/vista_mujeres.php">MUJERES</a>
    <a class="paginas" href="../php-hombres/vista_hombres.php">HOMBRES</a>
    <a class="paginas" href="../php-ninas/vista_niñas.php">NIÑAS</a>
    <a class="paginas" href="../php/vista_niños.php">NIÑOS</a>
  </div>
  <div class="conteiner">
    <br>
    <?php include('../php/ninos.php'); ?>
    <div class="row">
      <div class="col-12">
        <div class="row">
          <div class="col-md-5">
            <form action="" method="post">
              <div class="card">
                <div class="card-header">Registro Producto</div>
                <div class="card-body">
                <div class="mb-3">
                    <label for="id" class="form-label">ID</label>
                    <input type="text" class="form-control" name="id" value="<?php echo $id; ?>"
                    aria-describedby="helpId" placeholder="id">
                  </div>
                  <div class="mb-3">
                    <label for="nombre_prenda" class="form-label">Nombre</label>
                    <input type="text" class="form-control" name="nombre_prenda" value="<?php echo $nombre_prenda; ?>"
                      aria-describedby="helpId" placeholder="Nombre de la prenda">
                  </div>
                  <div class="mb-3">
                    <label for="talla" class="form-label">Talla</label>
                    <input type="text" class="form-control" name="talla" value="<?php echo $talla; ?>" aria-describedby="helpId"
                      placeholder="Talla de la prenda">
                  </div>
                  <div class="mb-3">
                    <label for="precio" class="form-label">Precio</label>
                    <input type="text" class="form-control" name="precio" value="<?php echo $precio; ?>" aria-describedby="helpId"
                      placeholder="Precio de la prenda">
                  </div>
                  <div class="mb-3">
                    <label for="existencia" class="form-label">Texto</label>
                    <input type="text" class="form-control" name="texto" value="<?php echo $texto; ?>" aria-describedby="helpId"
                      placeholder="informacion sobre la tienda">
                  </div>
                  <div class="mb-3">
                    <label for="existencia" class="form-label">Existencia</label>
                    <input type="text" class="form-control" name="existencia" value="<?php echo $existencia; ?>" aria-describedby="helpId"
                      placeholder="Existencia de la prenda">
                  </div>
                  <div class="btn-group" role="group" aria-label="">
                    <button type="submit" name="accion" value="agregar" class="btn btn-success">Agregar</button>
                    <button type="submit" name="accion" value="editar" class="btn btn-warning">Editar</button>
                    <button type="submit" name="accion" value="borrar" class="btn btn-danger">Borrar</button>
                  </div>
                </div>
              </div>
            </form>
          </div>

          <div class="col-md-7">
            <table class="table">
              <thead>
                <tr>
                <!--  <th scope="col">ID</th> -->
                  <th scope="col">Nombre</th>
                  <th scope="col">Talla</th>
                  <th scope="col">Precio</th>
                  <th scope="col">Texto</th>
                  <th scope="col">Existencia</th>
                  <th scope="col">Accion</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <?php foreach($listaRopa as $ropa){ ?>
                  <!--<td><?php echo $ropa['id']; ?></td>-->
                  <td><?php echo $ropa['nombre_prenda'];?></td>
                  <td><?php echo $ropa['talla'];?></td>
                  <td><?php echo $ropa['precio'];?></td>
                  <td><?php echo $ropa['texto'];?></td>
                  <td><?php echo $ropa['existencia'];?></td>
                  <td>
                    <form action="" method="post">
                    <input type="hidden" name="id" id="id" value="<?php echo $ropa['id']; ?>" />
                    <input type="submit" value="Seleccionar" name="accion" class="btn btn-info">
                    </form>
                  </td>
                </tr>
              <?php } ?> 
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Bootstrap JavaScript Libraries -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
    integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3"
    crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz"
    crossorigin="anonymous"></script>
</body>

</html>