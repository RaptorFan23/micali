<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="author" content="Texto como ejemplo">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, 
    minimum-scale=1.0">
    <title>CATALOGO DE ROPA UNISEX DE TEMPORADA</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/portada.CSS">
</head>

<body>

    <div id="encabezado">
    <a class="INICIO" href="../php/PORTADA.php">INICIO</a>
    <a class="INICIO" href="../php-mujeres/vista_mujeres.php">MUJERES</a>
    <a class="INICIO" href="../php-hombres/vista_hombres.php">HOMBRES</a>
    <a class="INICIO" href="../php-ninas/vista_niñas.php">NIÑAS</a>
    <a class="INICIO" href="../php/vista_niños.php">NIÑOS</a>
    <a id="carrito" href="../index.html"><img src="../css/Imagenes/casita.png" width="40px" height="40px"></a>
    </div>
        <div class="carrucel">
                <ul>
                <li>
                    <img src="../css/Imagenes/micali (2).png" height="100px">
                </li>
                <li>
                    <img src="../css/Imagenes/carrocel1.png" height="100px">
                </li>
                <li>
                    <img src="../css/Imagenes/carrocel2.png" height="100px">
                </li>
                <li>
                    <img src="../css/Imagenes/carrocel3.png" height="100px">
                </li>
                <li>
                    <img src="../css/Imagenes/carrosel4.png" height="100px">
                </li>
                <li>
                    <img src="../css/Imagenes/carrocel8.png" height="100px">
                </li>
                <li>
                    <img src="../css/Imagenes/carrucel6.png" height="100px">
                </li>
                <li>
                    <img src="../css/Imagenes/carrocel7.png" height="100px">
                </li>
                <li>
                    <img src="../css/Imagenes/carrocel10.png" height="100px">
                </li>
                <li>
                    <img src="../css/Imagenes/carrocel11.png" height="100px">
                </li>
                <li>
                    <img src="../css/Imagenes/carrocel12.png" height="100px">
                </li>
                <li>
                    <img src="../css/Imagenes/carrocel13.png height="100px">
                </li>
                <li>
            </ul>
        </div>
    </div>
    <div class="contenedor">
        <div class="producto">
            <div class="productos">
                <h2>VISION</h2>
                <h3>Su visión es querer ser una marca con innovación y diseños,
                    dando así a los clientes el gusto y comodidad por vestir sus prendas
                    y proporcionar cada día un mejor servicio.
                </h3>
            </div>
            <div class="productos">
                <h2>MISION</h2>
                <h3>La misión es que sus clientes tengan una experiencia de compra
                    más agradable en cuanto a sus artículos de ropa y ser la mejor
                    opción para el cliente</h3>
            </div>
            <div class="productos">
                <H2>POLITICA</H2>
                <h3>La política de la tienden establecen el buen trato al cliente, siendo justos y
                    estableciendo valores.
                    Brindar trato justo y esmerado a todos los clientes en sus llamadas, en sus
                    solicitudes y reclamos considerando que el fin de la tienda es el servicio a la
                    comunidad del Estado de México
                </h3>
            </div>
        </div>
    </div>
</body>

</html>