<?php
include_once '../baseDatos/bd.php';
$conexionBD=BD::crearInstancia();

$id=isset($_POST['id'])?$_POST['id']:'';
$nombre_prenda=isset($_POST['nombre_prenda'])?$_POST['nombre_prenda']:'';
$talla=isset($_POST['talla'])?$_POST['talla']:'';
$precio=isset($_POST['precio'])?$_POST['precio']:'';
$texto=isset($_POST['texto'])?$_POST['texto']:'';
$existencia=isset($_POST['existencia'])?$_POST['existencia']:'';
$accion=isset($_POST['accion'])?$_POST['accion']:'';

/* print_r($_POST);*/

if($accion!=''){
    switch($accion){
        case 'agregar':
        $sql="INSERT INTO hombres(id, nombre_prenda, talla, precio, texto, existencia) VALUES(NULL,:nombre_prenda, :talla, :precio, :texto, :existencia)";
        $consulta=$conexionBD->prepare($sql);
        $consulta->bindParam(':nombre_prenda',$nombre_prenda);
        $consulta->bindParam(':talla',$talla);
        $consulta->bindParam(':precio',$precio);
        $consulta->bindParam(':texto',$texto);
        $consulta->bindParam(':existencia',$existencia);
        $consulta->execute();
        /*echo $sql;*/
        break;
        case 'editar':
            $sql="UPDATE hombres SET nombre_prenda=:nombre_prenda, talla=:talla, precio=:precio, texto=:texto, existencia=:existencia WHERE id=:id";
            $consulta=$conexionBD->prepare($sql);
            $consulta->bindParam(':id',$id);
            $consulta->bindParam('nombre_prenda',$nombre_prenda);
            $consulta->bindParam(':talla',$talla);
            $consulta->bindParam(':precio',$precio);
            $consulta->bindParam(':texto',$texto);
            $consulta->bindParam(':existencia',$existencia);
            $consulta->execute();
    /*  echo $sql; */
        break;
        case 'borrar':
            $sql="DELETE FROM hombres WHERE id=:id";
            $consulta=$conexionBD->prepare($sql);
            $consulta->bindParam(':id',$id);
            $consulta->execute();

        break;
        case "Seleccionar":
            $sql="SELECT * FROM hombres WHERE id=:id";
            $consulta=$conexionBD->prepare($sql);
            $consulta->bindParam(':id',$id);
            $consulta->execute();
            $ninos=$consulta->fetch(PDO::FETCH_ASSOC);
            $nombre_prenda=$ninos['nombre_prenda'];
            $talla=$ninos['talla'];
            $precio=$ninos['precio'];
            $texto=$ninos['texto'];
            $existencia=$ninos['existencia'];

        break;
    }
}

$consulta=$conexionBD->prepare("SELECT * FROM hombres");
$consulta->execute();
$listaRopa=$consulta->fetchAll();

/*
$nombre_prenda = $_POST['nombre_prenda'];
$talla = $_POST['talla'];
$precio = $_POST['precio'];
$texto = $_POST['texto'];
$existencia = $_POST['existencia'];

$query = "INSERT INTO `ninos`(`nombre_prenda`, `talla`, `precio`, `texto`, `existencia`) VALUES ('$nombre_prenda','$talla','$precio','$texto','$existencia')";

$resultado=$con->query($query);
if ($resultado){
    echo "Correcto";
}
else{
    echo "Error";
}*/


?>